package com.account.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.account.exceptions.AccountNotFoundException;
import com.account.exceptions.NotEnoughBalanceException;
import com.account.models.Account;
import com.account.models.AccountDTO;
import com.account.models.Transaction;
import com.account.services.AccountService;
import com.account.services.TransactionService;

@RestController
//@RequestMapping("/account")
public class AccountController {

	long tranFromAccount;
	long tranToAccount;
	double tranAmount;
	String tranType;
	String tranStatus;

	@Autowired
	AccountService accService;

	@Autowired
	TransactionService tranService;

	@PostMapping("/createAccount")
	public ResponseEntity<Object> createAccount(@RequestBody Account acc){
		if(accService.createAccount(acc)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
//	public String createAccount(@RequestBody @Validated Account account) {
//		return accService.createAccount(account);
//	}

	@PostMapping("/updateAccount")
	public ResponseEntity<Object> updateAccount(@RequestBody Account acc){
		if(accService.updateAccount(acc)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}

	@DeleteMapping("/deleteAccount/{accnum}")
	public ResponseEntity<Object> deleteAccount(@PathVariable("accnum") int accNumber) throws AccountNotFoundException{
		accService.deleteAccount(accNumber);
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
		
	}
//	public String deleteAccount(@PathVariable("accnum") long accNumber) {
//		return accService.deleteAccount(accNumber);
//	}

	@GetMapping("/getaccount/{accnum}")
	public Account getAccount(@PathVariable("accnum") long accNumber) {
		return accService.getAccount(accNumber);
	}

	@GetMapping("/getAccountlist")
	public ResponseEntity<AccountDTO> getAccountList(){
		AccountDTO dto=new AccountDTO();
		dto.setList(accService.getAccountList());
		return new ResponseEntity<AccountDTO>(dto,HttpStatus.OK);
	}
//	public List<Account> getAccountList() {
//		return accService.getAccountList();
//	}

	@GetMapping("/deposit/{accnum}/{amount}")
	public ResponseEntity<Object> depositAccount(@PathVariable("accnum") long accNumber,
			@PathVariable("amount") double amount) throws AccountNotFoundException  {
		    accService.depositAccount(accNumber, amount);
			return new ResponseEntity<Object>(HttpStatus.OK);
 
	}
	
	
	
//	@GetMapping("/deposit/{accnum}/{amount}")
//	public boolean depositAccount(@PathVariable("accnum") long accNumber, @PathVariable("amount") double amount) {
//		Transaction transaction = new Transaction();
//		tranFromAccount = accNumber;
//		tranAmount = amount;
//		tranType = "Deposit";
//
//		try {
//			tranStatus = "Success";
//			return accService.depositAccount(accNumber, amount);
//
//		} catch (AccountNotFoundException anf) {
//			tranStatus = "Failed";
//			//return anf.getMessage();
//			return false;
//		} finally {
//			transaction.setTranFromAccount(accNumber);
//			transaction.setTranAmount(amount);
//			transaction.setTranType(tranType);
//			transaction.setTranStatus(tranStatus);
//			tranService.createTransaction(transaction);
//		}
//
//	}

	@GetMapping("/withdraw/{accnum}/{amount}")
	public ResponseEntity<Object> withdrawAccount(@PathVariable("accnum") long accNumber,
			@PathVariable("amount") double amount) throws NotEnoughBalanceException, AccountNotFoundException   {
		    accService.withdrawAccount(accNumber, amount);
			return new ResponseEntity<Object>(HttpStatus.OK);
 
	}
//	@GetMapping("/withdraw/{accnum}/{amount}")
//	public boolean withdrawAccount(@PathVariable("accnum") long accNumber, @PathVariable("amount") double amount) {
//		Transaction transaction = new Transaction();
//		tranFromAccount = accNumber;
//		tranAmount = amount;
//		tranType = "Withdraw";
//		try {
//			tranStatus = "Success";
//			return accService.withdrawAccount(accNumber, amount);
//		} catch (AccountNotFoundException anf) {
//			tranStatus = "Failed";
//			//return anf.getMessage();
//			return false;
//		} catch (NotEnoughBalanceException nef) {
//			tranStatus = "Failed";
//			//return nef.getMessage();
//			return false;
//		} finally {
//			transaction.setTranFromAccount(accNumber);
//			transaction.setTranAmount(amount);
//			transaction.setTranType(tranType);
//			transaction.setTranStatus(tranStatus);
//			tranService.createTransaction(transaction);
//		}
//	}

//	 public abstract String FundTransferAccount(long fromAccNumber,long
//	 toAccNumber,double amount);
	
	@GetMapping("/fundtransfer/{fromaccnum}/{toaccnum}/{amount}")
	public ResponseEntity<Object> FundTransferAccount(@PathVariable("fromaccnum") long fromAccNumber,@PathVariable("toaccnum") long toAccNumber,
			@PathVariable("amount") double amount) throws NotEnoughBalanceException, AccountNotFoundException   {
		    accService.FundTransferAccount(fromAccNumber, toAccNumber, amount);
			return new ResponseEntity<Object>(HttpStatus.OK);
 
	}
	
//	@GetMapping("/fundtransfer/{fromaccnum}/{toaccnum}/{amount}")
//	public boolean FundTransferAccount(@PathVariable("fromaccnum") long fromAccNumber,
//			@PathVariable("toaccnum") long toAccNumber, @PathVariable("amount") double amount) {
//		try {
//			return accService.FundTransferAccount(fromAccNumber, toAccNumber, amount);
//		} catch (AccountNotFoundException anf) {
//
//			//return anf.getMessage();
//			return false;
//		} catch (NotEnoughBalanceException nef) {
//			//return nef.getMessage();
//			return false;
//		}
//	}

}
