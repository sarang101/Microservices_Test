package com.account.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.dao.TransactionDao;
import com.account.models.Transaction;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	TransactionDao tranDao;

	@Override
	public String createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		tranDao.save(transaction);
		return "Transaction added successfully";
	}

	@Override
	public String updateTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		tranDao.save(transaction);
		return "Transaction updated successfully";
	}

	@Override
	public String deleteTransaction(int tranId) {
		// TODO Auto-generated method stub
		tranDao.deleteById(tranId);
		return "Transaction deleted successfully";
	}

	@Override
	public Transaction getTransaction(int tranId) {
		// TODO Auto-generated method stub
		Optional<Transaction> optional = tranDao.findById(tranId);
		return optional.get();
	}

	@Override
	public List<Transaction> getAllTransaction() {
		// TODO Auto-generated method stub
		return tranDao.findAll();
	}

	@Override
	public List<Transaction> getAllTransactionByAccNumber(long accNumber) {
		// TODO Auto-generated method stub
		return tranDao.getAllTransactionByAccNumber(accNumber);
	}

}
