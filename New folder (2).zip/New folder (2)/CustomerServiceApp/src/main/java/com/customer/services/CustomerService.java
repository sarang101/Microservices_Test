package com.customer.services;

import java.util.List;

import com.customer.exceptions.CustomerNotFound;
import com.customer.models.Customer;

public interface CustomerService {

	public abstract boolean createCustomer(Customer customer);

	public abstract boolean updateCustomer(Customer customer);

	public abstract boolean deleteCustomer(int cusId)throws CustomerNotFound;

	public abstract Customer getCustomerById(int cusId);

	public abstract List<Customer> getAllCustomer();
}
