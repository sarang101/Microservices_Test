package com.customer.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.customer.exceptions.CustomerNotFound;
import com.customer.models.Customer;
import com.customer.models.CustomerDTO;
import com.customer.services.CustomerService;

@RestController
//@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	CustomerService cusService;
	

	@PostMapping("/createCustomer")
	public ResponseEntity<Object> createCustomer(@RequestBody Customer cus){
		if(cusService.createCustomer(cus)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
//	public String createCustomer(@RequestBody @Validated Customer customer) // http://localhost:8080/customer/createCustomer
//	{
//		return cusService.createCustomer(customer);
//	}

	@PostMapping("/updateCustomer")
	public ResponseEntity<Object> updateCustomer(@RequestBody Customer cus){
		if(cusService.updateCustomer(cus)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
//	public String updateCustomer(@RequestBody Customer customer) {
//		return cusService.updateCustomer(customer);
//	}

	@DeleteMapping("/deleteCustomer/{cusid}")
	public ResponseEntity<Object> deleteCustomer(@PathVariable("cusid") int cusId) throws CustomerNotFound{
		cusService.deleteCustomer(cusId);
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
		
	}
//	public String deleteCustomer(@PathVariable("cusid") int cusId) {
//		try {
//		return cusService.deleteCustomer(cusId);
//		}catch(CustomerNotFound cnf) {
//			return cnf.getMessage();
//		}
//	}

	@GetMapping("/getbyid/{cusid}")
	public Customer getCustomerById(@PathVariable("cusid") int cusId) {
		return cusService.getCustomerById(cusId);		
	}

	@GetMapping("/getall")
	public ResponseEntity<CustomerDTO> getAllCustomer(){
		CustomerDTO dto=new CustomerDTO();
		dto.setList(cusService.getAllCustomer());
		return new ResponseEntity<CustomerDTO>(dto,HttpStatus.OK);
	}
	
//	public List<Customer> getAllCustomer() {
//		return cusService.getAllCustomer();
//	}

}
