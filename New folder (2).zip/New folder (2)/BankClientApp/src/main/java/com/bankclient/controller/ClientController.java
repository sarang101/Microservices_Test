package com.bankclient.controller;

import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.bankclient.models.Account;
import com.bankclient.models.AccountDTO;
import com.bankclient.models.ApplicationUser;
import com.bankclient.models.Customer;
import com.bankclient.models.CustomerDTO;
import com.bankclient.models.Transaction;
import com.bankclient.models.TransactionDTO;

@Controller
public class ClientController {

	@Autowired
	private RestTemplate restTemplate;
//	@Autowired
//	private DiscoveryClient discoveryClient;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@PostMapping("/userlogin")
	public String userLogin(@RequestParam("username") String username,@RequestParam("password") String password , Model model,HttpSession session) {
		System.out.println(username);
		System.out.println(password);
		ApplicationUser user=new ApplicationUser();
		
		user.setUsername(username);
		user.setPassword(password);
		int status;
		try {
			
		ResponseEntity<ApplicationUser> res=restTemplate.postForEntity("http://localhost:8090/authservice/auth", user, ApplicationUser.class);
		ApplicationUser userObj=(ApplicationUser) res.getBody();
		System.out.println(userObj);
		session.setAttribute("userId", userObj.getUserId());
		status=res.getStatusCodeValue();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/getall";
		}
		catch(Exception e)
		{
			status=400;
			model.addAttribute("message","UserName and Password invalid"+e);		
			
			return "home";
		}	
	}
	
	//*****************************************************************************
	@GetMapping("/getall")
	public String getAllcustomer(HttpSession session) {
		CustomerDTO dto=restTemplate.getForObject("http://localhost:8092/customerService/getall",CustomerDTO.class);
		//model.addAttribute("ProductList",dto.getList());
		session.setAttribute("CustomerList", dto.getList());
		return "customerList";
	}
	
	@GetMapping("/deleteCustomer/{cusid}")
	public String deleteCustomer(@PathVariable("cusid") int cusId) {
		restTemplate.delete("http://localhost:8092/customerService/deleteCustomer/"+cusId);
		return"redirect:/getall";
	}
	
	
	@PostMapping("/createCustomer")
	public String createCustomer(
			@RequestParam("cusName") String cusName,
			@RequestParam("cusEmail") String cusEmail,
			@RequestParam("cusMob") long cusMob,
			@RequestParam("cusAadhar") long cusAadhar,
			@RequestParam("cusPrmaAdd") String cusPrmaAdd,
			@RequestParam("cusResiAdd") String cusResiAdd,
			@RequestParam("cusDob") String cusDob,
			Model model,
			HttpSession session) {
			
			Customer cust=new Customer();
			
			cust.setCusId(0);
			cust.setCusName(cusName);
			cust.setCusDob(cusDob);
			cust.setCusMob(cusMob);
			cust.setCusEmail(cusEmail);
			cust.setCusAadhar(cusAadhar);
			cust.setCusPrmaAdd(cusPrmaAdd);
			cust.setCusResiAdd(cusResiAdd);
			int status;
			try {
				
			ResponseEntity<Customer> res=restTemplate.postForEntity("http://localhost:8092/customerService/createCustomer", cust, Customer.class);
			Customer customer=(Customer) res.getBody();
			System.out.println(customer);;
			System.out.println(res.getStatusCodeValue());
			return "redirect:/getall";
			}
			catch(Exception e)
			{
				status=400;
				model.addAttribute("message","UserName and Password invalid"+e);		
				
				return "home";
			}
			
	}
	
	@PostMapping("/updateCustomer")
	public String updateCustomer(@RequestParam("cusid") int cusId,
			@RequestParam("cusName") String cusName,
			@RequestParam("cusEmail") String cusEmail,
			@RequestParam("cusMob") long cusMob,
			@RequestParam("cusAadhar") long cusAadhar,
			@RequestParam("cusPrmaAdd") String cusPrmaAdd,
			@RequestParam("cusResiAdd") String cusResiAdd,
			@RequestParam("cusDob") String cusDob,
			Model model,
			HttpSession session) {
			
			Customer cust=new Customer();
			
			cust.setCusId(cusId);
			cust.setCusName(cusName);
			cust.setCusDob(cusDob);
			cust.setCusMob(cusMob);
			cust.setCusEmail(cusEmail);
			cust.setCusAadhar(cusAadhar);
			cust.setCusPrmaAdd(cusPrmaAdd);
			cust.setCusResiAdd(cusResiAdd);
			int status;
			try {
				
			ResponseEntity<Customer> res=restTemplate.postForEntity("http://localhost:8092/customerService/updateCustomer", cust, Customer.class);
			Customer customer=(Customer) res.getBody();
			System.out.println(customer);
			System.out.println(res.getStatusCodeValue());
			return "redirect:/getall";
			}
			catch(Exception e)
			{
				status=400;
				model.addAttribute("message","UserName and Password invalid"+e);		
				
				return "home";
			}
			
	}
	//***********************************************************************************
	
	@GetMapping("/getAccountlist")
	public String getAccountList(HttpSession session) {
		AccountDTO dto=restTemplate.getForObject("http://localhost:8094/accountService/getAccountlist",AccountDTO.class);
		//model.addAttribute("ProductList",dto.getList());
		session.setAttribute("AccountList", dto.getList());
		return "accountList";
	}
	
	@PostMapping("/createAccount")
	public String createAccount(
			@RequestParam("accBalance") double accBalance,
			@RequestParam("accBranch") String accBranch,
			@RequestParam("accOpenDate") String accOpenDate,
			@RequestParam("accType") String accType,
			Model model,
			HttpSession session) {
			
		    Account acc=new Account();
			
			acc.setAccNumber(0);
			acc.setAccBalance(accBalance);
			acc.setAccBranch(accBranch);
			acc.setAccOpenDate(accOpenDate);
			acc.setAccType(accType);
			int status;
			try {
				
			ResponseEntity<Account> res=restTemplate.postForEntity("http://localhost:8094/accountService/createAccount", acc, Account.class);
			Account account=(Account) res.getBody();
			System.out.println(account);;
			System.out.println(res.getStatusCodeValue());
			return "redirect:/getAccountlist";
			}
			catch(Exception e)
			{
				status=400;
				model.addAttribute("message","UserName and Password invalid"+e);		
				
				return "home";
			}
			
	}
	
	@PostMapping("/updateAccount")
	public String updateAccount(@RequestParam("accNumber") long accNumber,
			@RequestParam("accBalance") double accBalance,
			@RequestParam("accBranch") String accBranch,
			@RequestParam("accOpenDate") String accOpenDate,
			@RequestParam("accType") String accType,
			Model model,
			HttpSession session) {
			
		    Account acc=new Account();
			
			acc.setAccNumber(accNumber);
			acc.setAccBalance(accBalance);
			acc.setAccBranch(accBranch);
			acc.setAccOpenDate(accOpenDate);
			acc.setAccType(accType);
			int status;
			try {
				
			ResponseEntity<Account> res=restTemplate.postForEntity("http://localhost:8094/accountService/updateAccount", acc, Account.class);
			Account account=(Account) res.getBody();
			System.out.println(account);;
			System.out.println(res.getStatusCodeValue());
			return "redirect:/getAccountlist";
			}
			catch(Exception e)
			{
				status=400;
				model.addAttribute("message","UserName and Password invalid"+e);		
				
				return "home";
			}
			
	}
	
	@GetMapping("/deleteAccount/{accnum}")
	public String deleteAccount(@PathVariable("accnum") long accNumber){
		restTemplate.delete("http://localhost:8094/accountService/deleteAccount/"+accNumber);
		return"redirect:/getAccountlist";
	}
	
	@GetMapping("/deposit")
	public String depositAccount(
			@RequestParam("accnum") long accNumber,
			@RequestParam("amount") double amount, 
			Model model, 
			HttpSession session) {
		
		restTemplate.getForObject("http://localhost:8094/accountService/deposit/"+accNumber+"/"+amount,Account.class);
		
		Transaction transaction = new Transaction();
		transaction.setTranAmount(amount);
		transaction.setTranType("Deposit");
		transaction.setTranToAccount(0);
		transaction.setTranFromAccount(accNumber);
		
		ResponseEntity<Transaction> res=restTemplate.postForEntity("http://localhost:8096/transactionService/createTransaction",transaction,Transaction.class);
		Transaction transaction1=(Transaction) res.getBody();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/getAccountlist";
	}
	
	@GetMapping("/withdraw")
	public String withdrawAccount(
			@RequestParam("accnum") long accNumber,
			@RequestParam("amount") double amount, 
			Model model, 
			HttpSession session) {
		
		restTemplate.getForObject("http://localhost:8094/accountService/withdraw/"+accNumber+"/"+amount,Account.class);
		
		Transaction transaction = new Transaction();
		transaction.setTranAmount(amount);
		transaction.setTranType("Withdraw");
		transaction.setTranToAccount(0);
		transaction.setTranFromAccount(accNumber);
		
		ResponseEntity<Transaction> res=restTemplate.postForEntity("http://localhost:8096/transactionService/createTransaction",transaction,Transaction.class);
		Transaction transaction1=(Transaction) res.getBody();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/getAccountlist";
	}
	
	
	@GetMapping("/fundtransfer")
	public String withdrawAccount(
			@RequestParam("fromaccnum") long fromAccNumber,
			@RequestParam("toaccnum") long toAccNumber,
			@RequestParam("amount") double amount, 
			Model model, 
			HttpSession session) {
		
		restTemplate.getForObject("http://localhost:8094/accountService/fundtransfer/"+fromAccNumber+"/"+toAccNumber+"/"+amount,Account.class);
		
		Transaction transaction = new Transaction();
		transaction.setTranAmount(amount);
		transaction.setTranType("Fund Transfer");
		transaction.setTranToAccount(toAccNumber);
		transaction.setTranFromAccount(fromAccNumber);
		
		ResponseEntity<Transaction> res=restTemplate.postForEntity("http://localhost:8096/transactionService/createTransaction",transaction,Transaction.class);
		Transaction transaction1=(Transaction) res.getBody();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/getAccountlist";
	}
	
	//**************************************************************************
	
	@GetMapping("/getalltransaction")
	public String getTransaction(HttpSession session) {
		TransactionDTO dto=restTemplate.getForObject("http://localhost:8096/transactionService/getalltransaction",TransactionDTO.class);
		//model.addAttribute("ProductList",dto.getList());
		session.setAttribute("TransactionList", dto.getList());
		return "transactionList";
	}
	
	@PostMapping("/createTransaction")
	public String createTransaction(
			@RequestParam("tranFromAccount") long tranFromAccount,
			@RequestParam("tranToAccount") long tranToAccount,
			@RequestParam("tranAmount") double tranAmount,
			@RequestParam("tranTime") @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date tranTime,
			@RequestParam("tranType") String tranType,
			@RequestParam("tranStatus") String tranStatus,
			Model model,
			HttpSession session) {
			
		    Transaction trans=new Transaction();
			trans.setTranId(0);
			trans.setTranFromAccount(tranFromAccount);
			trans.setTranToAccount(tranToAccount);
			trans.setTranAmount(tranAmount);
			trans.setTranTime(tranTime);
			trans.setTranType(tranType);
			trans.setTranStatus(tranStatus);
			
			int status;
			try {
				
			ResponseEntity<Transaction> res=restTemplate.postForEntity("http://localhost:8096/transactionService/createTransaction", trans, Transaction.class);
			Transaction transaction=(Transaction) res.getBody();
			System.out.println(transaction);
			System.out.println(res.getStatusCodeValue());
			return "redirect:/getalltransaction";
			}
			catch(Exception e)
			{
				status=400;
				model.addAttribute("message","UserName and Password invalid"+e);		
				
				return "home";
			}
			
	}
	
	@PostMapping("/updateTransaction")
	public String updateTransaction(@RequestParam("tranId") int tranId,
			@RequestParam("tranFromAccount") long tranFromAccount,
			@RequestParam("tranToAccount") long tranToAccount,
			@RequestParam("tranAmount") double tranAmount,
			@RequestParam("tranTime") @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date tranTime,
			@RequestParam("tranType") String tranType,
			@RequestParam("tranStatus") String tranStatus,
			Model model,
			HttpSession session) {
			
		    Transaction trans=new Transaction();
			trans.setTranId(tranId);
			trans.setTranFromAccount(tranFromAccount);
			trans.setTranToAccount(tranToAccount);
			trans.setTranAmount(tranAmount);
			trans.setTranTime(tranTime);
			trans.setTranType(tranType);
			trans.setTranStatus(tranStatus);
			
			int status;
			try {
				
			ResponseEntity<Transaction> res=restTemplate.postForEntity("http://localhost:8096/transactionService/updateTransaction", trans, Transaction.class);
			Transaction transaction=(Transaction) res.getBody();
			System.out.println(transaction);
			System.out.println(res.getStatusCodeValue());
			return "redirect:/getalltransaction";
			}
			catch(Exception e)
			{
				status=400;
				model.addAttribute("message","UserName and Password invalid"+e);		
				
				return "home";
			}
			
	}
	
	@GetMapping("/deleteTransaction/{tranid}")
	public String deleteTransaction(@PathVariable("tranid") int tranId){
		restTemplate.delete("http://localhost:8096/transactionService/deleteTransaction/"+tranId);
		return"redirect:/getalltransaction";
	}
	
//	@GetMapping("/viewCart")
//	public String getCartItems(HttpSession session) {
//		CartDTO dto= new CartDTO();
//		try {
//		dto=restTemplate.getForObject("http://localhost:8084/cartservice/getCartItems",CartDTO.class);
//		
//		List<Cart> list=dto.getList();
//		System.out.println(list);
//		session.setAttribute("cartItems", list);
//		}
//		catch(Exception e) {
//			System.out.println(e.getMessage());
//			return "Cart";
//		}
//		return "Cart";
//	}
//	

//	
//	@GetMapping("/placeOrder")
//	public String placeOrder(HttpSession session) {
//		List<Cart> cartList=(List<Cart>) session.getAttribute("cartItems");
//		List<OrderItem> items=new ArrayList();
//		int grandTotal=0;
//		for(Cart c:cartList) {
//			OrderItem o=new OrderItem();
//			//o.setOrderId(0);
//			o.setProductid(c.getProductId());
//			o.setProductName(c.getProductname());
//			o.setProductPrice(c.getProductPrice());
//			o.setQuantity(c.getQuantity());
//			o.setSubTotal(c.getSumTotal());
//			grandTotal+=c.getSumTotal();
//			items.add(o);
//		
//		}
//		session.setAttribute("orderItems",items);
//		session.setAttribute("grandTotal",grandTotal);
//		
//		return "PlaceOrder";
//	}
//	
//	@PostMapping("/confirmOrder")
//	public String confirmOrder(@RequestParam("address") String address,@RequestParam("mode") String mode, HttpSession session) {
//		
//		long millis=System.currentTimeMillis();  
//        java.sql.Date date=new java.sql.Date(millis);  
//        if(session.getAttribute("userId")==null) {
//        	return "SessionExpired";
//        }
//		
//		Order order=new Order();
//		order.setDeliveryAddress(address);
//		order.setPaymentMode(mode);
//		order.setOrderAmount((int) session.getAttribute("grandTotal"));
//		order.setUserid((int) session.getAttribute("userId"));
//		order.setOrderItems((List<OrderItem>) session.getAttribute("orderItems"));
//		order.setOrderDate(date);
//		System.out.println(order.getOrderItems());
//		ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8085/orderservice/placeOrder", order, Object.class);
//		System.out.println(res.getStatusCodeValue());
//		restTemplate.delete("http://localhost:8084/cartservice/deleteAll");
//		
//		
//		List<Cart> cartList=null;
//		session.setAttribute("cartItems", cartList);
//		
//		return "Thanks";
//	}
	
}
