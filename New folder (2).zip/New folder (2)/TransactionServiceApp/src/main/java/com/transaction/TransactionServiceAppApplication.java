package com.transaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionServiceAppApplication.class, args);
	}

}
